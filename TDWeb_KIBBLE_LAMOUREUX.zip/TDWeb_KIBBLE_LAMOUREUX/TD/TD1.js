// Initialisation du tableau contenant les ouvrages
ouvrages = new Array();
nombreOuvrages = 0;

// Indice des éléments dans le tableau d'un ouvrage
indiceReference = 0;
indiceTitre = 1;
indiceAuteurs = 2;
indiceEditeur = 3;
indiceEdition = 4;
indiceAnnee = 5;
indiceIsbn = 6;
indiceNombreExemplaires = 7;
indiceDisponibilite = 8;
indiceExcluPret = 9;
indiceCommentaires = 10;

// Indices des messages d'erreur dans le tableau des erreurs
referenceNonRenseignee = 0;
referenceLettreRequise = 1;
titreNonRenseigne = 2;
auteursNonRenseignes = 3;
editeurNonRenseigne = 4;
editionNonRenseignee = 5;
editionDoitEtreNombre = 6;
anneeNonRenseignee = 7;
anneeDoitEtreNombre4Chiffres = 8;
isbnNonRenseigne = 9;
isbnDoitEtreNombre = 10;
nombreExemplairesNonRenseigne = 11;
nombreExemplairesDoitEtreNombre = 12;

// Initialisation du tableau des erreurs
tableauErreurs = new Array(
	"Veuillez renseigner la référence.",
	"La référence ne doit contenir que des chiffres ou des lettres non accentuées, dont au moins une lettre.",
	"Veuillez renseigner le titre.",
	"Veuillez renseigner l'auteur.",
	"Veuillez renseigner l'éditeur.",
	"Veuillez renseigner l'édition.",
	"L'édition doit être un nombre.",
	"Veuillez renseigner l'année d'édition.",
	"L'année d'édition doit être un nombre de 4 chiffres.",
	"Veuillez renseigner l'ISBN.",
	"L'ISBN doit être un nombre.",
	"Veuillez renseigner le nombre d'exemplaires.",
	"Le nombre d'exemplaires doit être un nombre.");




// Affiche le message de l'erreur dont le numero est passe en argument
function afficheErreur(numeroErreur)
{
	alert(tableauErreurs[numeroErreur]);
}

// Vérifie que la chaîne ne contient que des chiffres ou des lettres non accentuée A-Z, a-z
// et au moins une lettre
function verifier(reference)
{
	/*
	var longueur = reference.length;
	var vuUneLettre = false;
	var i;
	var ok;
	var c;
	for (i = 0; i < longueur; i++)
	{
		ok = false;
		c = reference.charAt(i);
		XXXXXXXXXXXXXXXXXXXXXXXXXXXX
	return vuUneLettre;
	*/

	/*booléen permettant de savoir si la chaîne de caractères contient au moins une lettre
	(true -> contient au moins une lettre, false sinon)*/
	var checkLettre = false;

	//variable permettant de stocker chaque caractère de la chaîne à vérifier
	var caractere;

	//indice de parcours de la chaîne de caractères
	var i;

	//On parcourt la chaîne de caractères
	for(i=0; i<reference.length;i++){
		//on récupère chaque caractère
		c = reference.charAt(i);
		//Si le caractère n'est pas alphanumérique (sans accent) on retourne false
		if(!(c.match(/[A-Z0-9]/gi))){
			return false;
		}
		//Sinon, si le caractère est une lettre et que c'est la première lettre rencontrée, on passe à true le booléen
		else if(c.match(/[A-Za-z]/i) && !checkLettre){
			checkLettre = true;
		}
	}
	return checkLettre;

}

// Affiche le resume de l'ouvrage dans le champ de meme nom
function afficherResume(ouvrage)
{
	var resume = nombreOuvrages + "-----------------\n"+
		"Ref : " + ouvrage[indiceReference] + "\n" +
		"Titre : " + ouvrage[indiceTitre] + "\n" +
		"Auteur : " + ouvrage[indiceAuteurs] + "\n" +
		"Editeur : " + ouvrage[indiceEditeur] + "\n" +
		"Edition : " + ouvrage[indiceEdition] + "\n" +
		"Année : " + ouvrage[indiceAnnee] + "\n" +
		"ISBN : "+ ouvrage[indiceIsbn] + "\n" +
		"Nbr Exemplaires : " + ouvrage[indiceNombreExemplaires] + "\n";

	var disponibilite = "Non disponible";
	if (ouvrage[indiceDisponibilite]){
		disponibilite = "Disponible";
	}
	resume += disponibilite + "\n";

	var excluPret = "Autorisé au prêt";
	if (ouvrage[indiceExcluPret]){
		excluPret = "Exclu du prêt";
	}
	resume += excluPret + "\n";
	if(ouvrage[indiceCommentaires].length!=0){
		resume += "Commentaires : " + ouvrage[indiceCommentaires]+"\n";
	}
	document.getElementById("resume").value = resume+document.getElementById("resume").value;

	var tr = document.createElement('tr');
	document.getElementById("tbOeuvres").appendChild(tr);
	var tdnum = document.createElement('td');
	var tdref = document.createElement('td');
	var tdtit = document.createElement('td');
	var tdaut = document.createElement('td');
	var tded1 = document.createElement('td');
	var tded2 = document.createElement('td');
	var tdann = document.createElement('td');
	var tdisb = document.createElement('td');
	var tdnbe = document.createElement('td');
	var tddis = document.createElement('td');
	var tdpre = document.createElement('td');
	var tdcom = document.createElement('td');
	var tdact = document.createElement('td');

	tdnum.appendChild(document.createTextNode(nombreOuvrages));
	tdref.appendChild(document.createTextNode(ouvrage[indiceReference]));
	tdtit.appendChild(document.createTextNode(ouvrage[indiceTitre]));
	tdaut.appendChild(document.createTextNode(ouvrage[indiceAuteurs]));
	tded1.appendChild(document.createTextNode(ouvrage[indiceEditeur]));
	tded2.appendChild(document.createTextNode(ouvrage[indiceEdition]));
	tdann.appendChild(document.createTextNode(ouvrage[indiceAnnee]));
	tdisb.appendChild(document.createTextNode(ouvrage[indiceIsbn]));
	tdnbe.appendChild(document.createTextNode(ouvrage[indiceNombreExemplaires]));
	var dispT = 'o';
	var pretT = 'o';
	if(ouvrage[indiceExcluPret]){
		pretT = 'n';
	}
	if(!(ouvrage[indiceDisponibilite])){
		dispT='n';
	}
	tddis.appendChild(document.createTextNode(dispT))
	tdpre.appendChild(document.createTextNode(pretT));
	tdcom.appendChild(document.createTextNode(ouvrage[indiceCommentaires]));

	var supprOeuvre = document.createElement('button');
	supprOeuvre.appendChild(document.createTextNode('Supprimer'));

	supprOeuvre.addEventListener("click",function(){
		alert("Désolé, ce bouton ne fonctionne pas encore.");
		/*var idOeuvre = Number(tdnum.value)-1;
		for(idOeuvre; idOeuvre<nombreOuvrages-1; idOeuvre++){
			ouvrages[idOeuvre] = ouvrages[idOeuvre+1];
		}
		var i;
		nombreOuvrages-=1;
		document.getElementById("tbOeuvres").deleteRow(idOeuvre);
		*/
	});

	tdact.appendChild(supprOeuvre);

	tr.appendChild(tdnum);
	tr.appendChild(tdref);
	tr.appendChild(tdtit);
	tr.appendChild(tdaut);
	tr.appendChild(tded1);
	tr.appendChild(tded2);
	tr.appendChild(tdann);
	tr.appendChild(tdisb);
	tr.appendChild(tdnbe);
	tr.appendChild(tddis);
	tr.appendChild(tdpre);
	tr.appendChild(tdcom);
	tr.appendChild(tdact);


	alert("Saisie d'un ouvrage effectuée");
}

function reset_validation(){
	document.getElementById("reference").value = "";
	document.getElementById("titre").value = "";
	document.getElementById("auteurs").value = "";
	document.getElementById("editeur").value = "";
	document.getElementById("edition").value = "";
	document.getElementById("annee").value = "";
	document.getElementById("isbn").value = "";
	document.getElementById("nombreExemplaires").value = "";
	document.getElementById("Disponibilite").value = "";
	document.getElementById("excluPret").value = "";
	document.getElementById("Commentaires").value = "";
	document.getElementById("Disponibilite").checked = false;
	document.getElementById("excluPret").checked = false;
}

// Validation et ajout d'un ouvrage
function validation()
{
	var reference = new String(document.getElementById("reference").value);
	if (reference.length == 0)
	{
		return afficheErreur(referenceNonRenseignee);
	}

	if (!verifier(reference))
	{
		return afficheErreur(referenceLettreRequise);
	}

	var titre = new String(document.getElementById("titre").value);
	if (titre.length == 0)
	{
		return afficheErreur(titreNonRenseigne);
	}

	var auteurs = new String(document.getElementById("auteurs").value);
	if (auteurs.length == 0)
	{
		return afficheErreur(auteursNonRenseignes);
	}

	var editeur = new String(document.getElementById("editeur").value);
	if (editeur.length == 0)
	{
		return afficheErreur(editeurNonRenseigne);
	}

	var edition = new String(document.getElementById("edition").value);
	if (edition.length == 0)
	{
		return afficheErreur(editionNonRenseignee);

	}
	if (isNaN(edition))
	{
		return afficheErreur(editionDoitEtreNombre);

	}

	var annee = new String(document.getElementById("annee").value);
	if (annee.length == 0)
	{
		return afficheErreur(anneeNonRenseignee);

	}
	if (isNaN(annee) || annee.length != 4)
	{
		return afficheErreur(anneeDoitEtreNombre4Chiffres);

	}

	var isbn = new String(document.getElementById("isbn").value);
	if (isbn.length == 0)
	{
		return afficheErreur(isbnNonRenseigne);
	}
	if (isNaN(isbn))
	{
		return afficheErreur(isbnDoitEtreNombre);

	}

	var nombreExemplaires = new String(document.getElementById("nombreExemplaires").value);
	if (nombreExemplaires.length == 0)
	{
		return afficheErreur(nombreExemplairesNonRenseigne);

	}
	if (isNaN(nombreExemplaires))
	{
		// Afficher Erreur Correspondante
		return afficheErreur(isbnDoitEtreNombre);

	}

	var disponibilite = document.getElementById("Disponibilite").checked;
	var excluPret = document.getElementById("excluPret").checked;
	var commentaires = new String(document.getElementById("Commentaires").value);

	// crŽation d'un ouvrage

	var ouvrage = new Array();
	ouvrage[indiceReference] = reference;
	ouvrage[indiceTitre] = titre;
	ouvrage[indiceAuteurs] = auteurs;
	ouvrage[indiceEditeur] = editeur;
	ouvrage[indiceEdition] = edition;
	ouvrage[indiceAnnee] = annee;
	ouvrage[indiceIsbn] = isbn;
	ouvrage[indiceNombreExemplaires] = nombreExemplaires;
	ouvrage[indiceDisponibilite] = disponibilite;
	ouvrage[indiceExcluPret] = excluPret;
	ouvrage[indiceCommentaires] = commentaires;
	ouvrages[nombreOuvrages] = ouvrage;
	nombreOuvrages++;

	afficherResume(ouvrage);
	reset_validation()

}

function clearDatabase(){
	var tab = document.getElementById('tbOeuvres');
	while(tab.rows.length!=0){
		tab.deleteRow(0);
	}
	ouvrages = new Array();
	nombreOuvrages = 0;
	this.form.reset();
	alert('La Bibliothèque a été vidée de ses oeuvres.')
}
