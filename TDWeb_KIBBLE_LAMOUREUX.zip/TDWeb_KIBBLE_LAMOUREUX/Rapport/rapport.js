introductionHTML = "<h2>1. INTRODUCTION</h2>"+
"<p>"+
"	Dans le cadre du cours de Web Service, nous avons étudié et mis en pratique trois langages d'intégration et de programmation web :"+
"	<ul>"+
"		<li> Le <a href='https://fr.wikipedia.org/wiki/HTML5'>HTML5</a> ; il s'agit d'un langage de balises étant interprétées par le navigateur afin d'afficher une page web. C'est ce langage qui va définir la <strong>structure de la page web</strong>."+
"		<li> Le <a href='https://fr.wikipedia.org/wiki/Feuilles_de_style_en_cascade'>CSS</a> ; il s'agit d'un langage permettant de <strong>mettre en forme</strong> une page web en déterminant des propriétés pour les différentes balises HTML constituant cette page.</li>"+
"		<li> Le <a href='https://fr.wikipedia.org/wiki/JavaScript'>JavaScript (JS)</a> ; il s'agit d'un langage de programmation principalement utilisé pour <strong>rendre une page web interractive</strong>. </li>"+
"	</ul>"+
"	Ces trois langages informatiques permettent de créer la structure et le contenu d'une page web (HTML5), mis en forme (CSS) et dynamique (JS)."+
"          <br/>"+
"	<br/>"+
"           Ce TD a pour objectif de mettre en pratique les compétences acquises à travers la création d'un formulaire de saisie d'ouvrages pour une bibliothèque."+
"</p>";

cahierDesChargesHTML = "<h2>2. CAHIER DES CHARGES</h2>"+
"<p>"+
"	Pour nous guider dans la création du formulaire, un modèle nous a été fourni :</p>"+
"	<img src='Modele.png'/>"+
"	<p>A partir de ce modèle, il nous a été demandé de réaliser un formulaire de saisie d’œuvres pour une bibliothèque."+
"	<br/>"+
" 	La structure de ce formulaire devait donc être la suivante :"+
"	<ul>"+
"		<li>un bloc qui contiendra le formulaire ;</li>"+
"		<li>un titre (\"Formulaire de saisie d'un ouvrage\") ;</li>"+
"		<li>les champs à renseigner pour la saisie d'un ouvrage (référence, titre, auteur, …) ; </li>"+
"		<li>des boutons de validation et d'annulation ; </li>"+
"		<li>une zone de texte non modifiable par l'utilisateur où sera affichées les informations de l’œuvre saisie ;</li>"+
"	</ul>"+
"	<br/>"+
" 	Ce formulaire doit ensuite respecter les règles de mise en forme suivantes :"+
"	<ol>"+
"		<li>la police doit être Helvetica 18px de couleur navy ;</li>"+
"		<li>le fond du formulaire doit être gris ;</li>"+
"		<li>les libellés correspondant aux zones à saisir doivent être en gras ; </li>"+
"		<li>le titre doit être en bleu ; </li>"+
"	</ol>"+
"	<br/>"+
"	Enfin, les actions et règles de gestion suivantes doivent être implémentées :"+
"	<ul>"+
"		<li>la référence d'une œuvre doit contenir au moins une lettre et ne contenir que des caractères alphanumériques simples (sans caractères spéciaux) ;</li>"+
"		<li>l'ISNB est un nombre ;</li>"+
"		<li>la valeur du champ 'Edition' doit être numérique ; </li>"+
"		<li>la valeur du nombre d'exemplaires doit être numérique ; </li>"+
"		<li>le bouton 'Annuler' doit nettoyer les zones de saisies et l'affichage ;</li>"+
"		<li>le bouton 'Valider la saisie' doit ajouter l’œuvre à la liste des œuvres stockées et l'afficher dans la zone de texte non modifiable ;</li>"+
"		<li>le bouton 'Valider la saisie' doit nettoyer la zone de saisies et afficher un message à l'utilisateur (\"Saisie d'un ouvrage effectuée\") ;</li>"+
"	</ul>"+
"	<br/>"+
"	<p> Après avoir étudié les demandes, nous avons identifié trois axes de développement dans cet exercice. La première partie du sujet concerne la structure de la page (HTML5), la seconde concerne sa mise en forme (CSS) et la troisième concerne les règles de gestion et diverses actions réalisables sur la page (Javascript)."+
"</p>";

implementationHTML = "<h2>3. IMPLEMENTATION</h2>"+
"<p>"+
"	Nous avons tout d'abord réalisé les fonctionnalités du cahier des charges."+
"	Pour réaliser un affichage comme dans le modèle fourni, nous avons structuré le formulaire sous la forme d'une table de 2 colonnes. La seconde colonne contient les zones de saisies tandis que la première contient les libellés associés. Cette structuration du code permet un affichage bien aligné des différents champs du formulaire."+
" <img src='code1.png'/>"+
" A noter que nous avons essayé d'intégrer le code via les balises figure/pre/code dans ce rapport, mais cela ne semble pas fonctionner à cause de la manière dont est géré l'affichage de la page."+
" <br/>"+
" <br/>"+
" Après avoir mis en forme la structure, nous avons donc réalisé les règles de gestion et actions."+
" <br/>"+
" Pour réaliser l'action d'ajouter une oeuvre, nous avons créé une fonction javascript permettant de récupérer les valeurs saisies par l'utilisateur et d'ajouter une oeuvre à un tableau."+
" Une fois l'oeuvre ajoutée, une 'alert' apparaît pour informer l'utilisateur que l'oeuvre a bien été ajoutée si tous les champs obligatoires étaient correctement remplis."+
" Dans le cas contraire, si un champ n'est pas correctement rempli par l'utilisateur, un message d'erreur l'en informera pour lui signaler le problème et comment le résoudre.</p>"+
"<br/>"+
"<br/>"+
"<p> Après avoir terminé les fonctionnalités principales, nous nous sommes penchés sur d'éventuelles améliorations afin d'obtenir un résultat plus agréable pour l'utilisateur, ou simplement plus 'visuel'."+
"	<br> Nous avons alors ajouté plusieurs fonctionnalités :"+
"	<ol>"+
"		<li> un affichage des oeuvres saisies en mode historique ; </li>"+
"		<li> un tableau d'affichage des oeuvres saisies ;</li>"+
"	</ol>"+
" <br/>"+
" <ul>"+
"		<li>L'affichage demandé initialement dans le cahier des charges était simplement un affichage dans une zone de texte de l'oeuvre saisie une fois celle-ci validée par l'utilisateur. Nous avons intégré à la place un système d'historique grâce auquel l'utilisateur peut voir à la fois la dernière oeuvre qu'il a validé, mais également celles qu'il a pu enregistrer au préalable. Cela permet à l'utilisateur de garder un suivi de ce qu'il a enregistré.</li>"+
"	<br> <img src='Test1_Zone_Historique.png'>"+
"	<br> <img src='Test2_Zone_Historique.png'>"+
"		<li>Dans la même logique d'affichage, nous avons ajouté un tableau dynamique dans lequel sont intégrées les oeuvres saisies par l'utilisateur. Celui-ci est mis à jour à chaque insertion d'une oeuvre par l'utilisateur et permet d'avoir un affichage plus agréable qu'une simple zone de texte.</li>"+
"	<br> <img src='Table_Historique.png'>"+
" </ul>"+
"	<br/>"+
" On peut également voir sur l'image ci-dessus qu'un bouton 'supprimer' est présent sur chaque ligne du tableau. En effet, celui-ci devrait permettre de supprimer une oeuvre du tableau (table de la base de données locale et le tableau affiché). Cependant, au vue de la manière dont nous avons géré les oeuvres et ce tableau, nous n'avons pas réussi à intégrer cette fonctionnalité. Ce bouton affiche donc une 'alert' pour signaler qu'il n'est pas fonctionnel pour le moment."+
"	<br/>"+
" Pour finir, nous avons intégré un troisième bouton à coté de ceux déjà présents dans le formulaire, permettant de supprimer toutes les oeuvres de la base de données de la bibliothèque."+
"</p>";

conclusionHTML = "<h2>4. CONCLUSION</h2>"+
"<p>"+
"	Malgré les difficultés rencontrés nous avons pu réaliser l'ensemble des fonctionnalités énoncées dans le cahier des charges."+
"	<br/>"+
" Cependant, nous n'avons pas pu implémenter la totalité des fonctionnalités que nous aurions aimé apporté à cet exercice (comme la suppression d'une oeuvre depuis le tableau via le bouton 'supprimer'), "+
"	<br/>"+
" En effet, notre manque de maîtrise du JavaScript et l'avancement de la date de rendu ne nous ont pas permis de mener à bien toutes nos idées."+
"	<br/>"+
" Nous avons tout de même des idées pour implémenter cette suppression :"+
" <ol>"+
"		<li> La première solution serait d'effectuer une modélisation objet de l'oeuvre avec un objet JavaScript. Cela nous permettrait d'effectuer beaucoup plus facilement certaines opérations comme la suppression d'un objet.</li>"+
"		<li> La seconde solution envisagée est de recharger le tableau à chaque suppression et ajout d'une oeuvre. En effet, ce tableau serait recréé à chaque action sur la liste des oeuvres et bien que le fait de recharger l'entièreté du code du tableau soit un 'lourd', cela permettrait d'avoir en permanence un tableau numéroté des oeuvres et de pouvoir les supprimer facilement.</li>"+
"	</ol>"+
" Pour conclure, nous dresserons donc un bilan positif de cet exercice puisqu'il nous a permis de comprendre les bases du web et de les pratiquer, mais également car nous avons pu respecter le cahier des charges."+
"</p>";

referenceHTML = "<h2>5. REFERENCES</h2>"+
"<p>"+
"	Ci-dessous, vous trouverez les liens qui nous ont aidé à réaliser le TD et le rapport :"+
"	<ul>"+
"		<li><a href='http://dept-info.labri.fr/~benois-p/WebServicesMIAGE/CoursWebServices2018_2019/'> Cours de Mme Benoit-Pineau Jenny</a></li>"+
"		<li><a href='https://openclassrooms.com/fr'>Openclassrooms</a></li>"+
"		<li><a href='https://www.w3schools.com/html/'>W3schools</a></li>"+
"		<li><a href='https://www.developpez.com/'>Developpez.net</a></li>"+
"	</ul>"+
"</p>";

tableauDesSections = new Array(introductionHTML,cahierDesChargesHTML,implementationHTML,conclusionHTML,referenceHTML);

function ecrireSection(sec){
	var cdp = document.getElementById('corpsDePage');
	cdp.innerHTML = "";
	var section = document.createElement('section');
	section.innerHTML = tableauDesSections[sec];
	cdp.appendChild(section);
}

window.onload = function()
{
	ecrireSection(0);
};
